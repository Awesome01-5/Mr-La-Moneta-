# Mr La Moneta — Sure Code (v5 Lite)

## Run locally

```bash
docker-compose up --build
```

## Open
http://localhost:8000