from fastapi import FastAPI
import requests

app = FastAPI()

@app.get("/")
def health():
    return {"status": "Mr La Moneta running"}

@app.get("/signal")
def signal():
    return {"signal": "BUY"}